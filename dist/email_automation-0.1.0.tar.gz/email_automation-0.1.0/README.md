# Email Automation

A simple Python library to automate sending emails with support for attachments.

## Installation

```bash
pip install email-automation
